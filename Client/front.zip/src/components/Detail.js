import React, { Fragment,useState } from 'react';
import {Link} from 'react-router-dom';
import {useDispatch,useSelector} from 'react-redux';
import {getDetail} from '../actions';
import { useEffect } from 'react';
import './styles/Detail.css';
import Paginado from './Paginng';



export default function Detail (props){
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(getDetail(props.match.params.id));
    },[dispatch,props.match.params.id]);

const countries=useSelector((state)=> state.detail);

const [currentPage,setcurrentPage]= useState(1);
const [paisesPerPage]= useState (10);
const indexlastCountry= currentPage * paisesPerPage ;
const indexfirstCountry= indexlastCountry - paisesPerPage;
const paisesPageActual= countries.slice(indexfirstCountry,indexlastCountry);
const  paginated=(NunberPage) => (setcurrentPage(NunberPage));
    
    return(
        <div className='body'> 

            <div> <h1>Detalles  de Paises con Actividades Turisticas</h1> </div>
             
            <div>
                <Link to='/'><button>Volver Inicio</button></Link>   
           </div>
        
           <div  className='Paginado'>
                       <Paginado
                         paisesPerPpage={paisesPerPage}
                         countries={countries.length}              
                         paginado={paginated}                                 
                       />
                 </div>

            

            {  paisesPageActual?.map((e)=>{
            return(
             <Fragment> 
              <div className='Body'> 
                  <h5>Id : {e.id}</h5>
                  <h5>País : {e.name}</h5>
                  <img src={e.flag } alt='' width='70px' height='70px'/>
                  <h5>Continente: {e.continent}</h5>
                  <h5>Capital: {e.capital}</h5>
                  <h5>Subregión: {e.subregion}</h5>
                  <h5>Superficie : {e.area} Km2</h5>
                  <h5>Habitantes: {e.population}</h5>
                  <h4>Actividades Turisticas: {e.tourisms.map(e=> <h5 key={e.id }>
                                                      <Link>
                                                         <h5> Nombre ={e.name}</h5>
                                                         <h5>Nivel={e.level}</h5>
                                                         <h5>Duracion hs ={e.time}</h5>
                                                         <h5>temporada ={e.season}</h5>                                                
                                                     </Link>
                                                        </h5>)}
                   </h4>
              </div>
              </Fragment>)})
            }:<p>Louding...</p>  


                   
           
       </div>
    )
};